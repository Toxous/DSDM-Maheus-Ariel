package com.codegemz.flutlab.login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
