package com.example.heitor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
