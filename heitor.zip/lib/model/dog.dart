class Dog {
  final int id;
  final String nome;
  final int idade;

  Dog({required this.id, required this.nome, required this.idade});

  Map<String, Object?> toMap() {
    return {'id': id, 'nome': nome, 'idade': idade};
  }

  String toString() {
    return 'Dog: {ID : $id, Nome: $nome, Idade: $idade}';
  }
}
