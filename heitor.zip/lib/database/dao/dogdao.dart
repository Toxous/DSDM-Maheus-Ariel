import 'package:heitor/database/db.dart';
import 'package:heitor/model/dog.dart';
import 'package:sqflite/sqflite.dart';

Future<int> insertDog(Dog cachorro) async {
  Database db = await getDatabase();
  return db.insert('dogs', cachorro.toMap(),
      conflictAlgorithm: conflictAlgorithm.replace);
}

Future<List<Map<String, dynamic> findall() async {
  Database db = await getDatabase();
  List<Map<String, dynamic>> dados = await db.query('dogs');
  
  dados.forEach((dog) {
    print(dog);
  });
  return dados;

  return dados;
}

Future<int> deleteById(int id) async{
  debugPrint("Deletando o ID: $id");
  Database db = await getDatabase();
  return db.delete('dogs', where: "id = ?", whereArgs: [id]);
}